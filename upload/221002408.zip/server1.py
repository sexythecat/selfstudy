import socket # 导入socket模块，用于网络通信
import os # 导入os模块，用于处理文件和目录

def start_server(): # 定义一个函数，用于启动服务器
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # 创建一个UDP套接字

    server_socket.bind(('0.0.0.0', 12345)) # 将套接字绑定到一个地址和端口

    while True: # 循环，直到程序被终止
        data, addr = server_socket.recvfrom(1024) # 从套接字接收数据，最多接收1024字节

        if data.startswith(b'FILE'): # 如果接收到的数据是文件的一部分
            filename, filedata = data[4:].split(b'\0', 1) # 从数据中获取文件名和文件数据
            with open(os.path.join('/home/jdqi/Desktop/here', filename.decode()), 'ab') as f: # 以二进制追加模式打开文件
                f.write(filedata) # 将文件数据写入文件
        else: # 如果接收到的数据不是文件的一部分
            print('Received message:', data, 'from:', addr) # 打印接收到的消息和发送者的地址

start_server() # 调用start_server函数启动服务器
