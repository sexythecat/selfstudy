import socket # 导入socket模块，用于网络通信
import os # 导入os模块，用于处理文件和目录
import argparse # 导入argparse模块，用于处理命令行参数

def send_file(filename, client_socket, server_ip, server_port): # 定义一个函数，用于发送文件
    with open(filename, 'rb') as f: # 以二进制读取模式打开文件
        while True: # 循环，直到文件读取完毕
            filedata = f.read(1024) # 每次读取1024字节的数据
            if not filedata: # 如果没有数据了，就跳出循环
                break
            # 将文件名和文件数据一起发送到服务器
            client_socket.sendto(b'FILE' + os.path.basename(filename).encode() + b'\0' + filedata, (server_ip, server_port))

def start_client(server_ip, server_port, directory): # 定义一个函数，用于启动客户端
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # 创建一个UDP套接字

    for root, dirs, files in os.walk(directory): # 遍历指定目录及其子目录
        for filename in files: # 对于目录中的每个文件
            send_file(os.path.join(root, filename), client_socket, server_ip, server_port) # 调用send_file函数发送文件

if __name__ == "__main__": # 如果这个脚本被直接运行，而不是被导入
    parser = argparse.ArgumentParser(description='UDP file sender') # 创建一个命令行参数解析器
    parser.add_argument('server_ip', type=str, help='请输入服务器的IP地址') # 添加一个需要用户输入的参数，表示服务器的IP地址
    parser.add_argument('server_port', type=int, help='请输入服务器的端口号') # 添加一个需要用户输入的参数，表示服务器的端口号
    parser.add_argument('directory', type=str, help='请输入要发送文件的目录') # 添加一个需要用户输入的参数，表示要发送文件的目录
    args = parser.parse_args() # 解析命令行参数

    print("开始连接服务器...") # 打印一条消息，表示开始连接服务器
    start_client(args.server_ip, args.server_port, args.directory) # 调用start_client函数启动客户端
    print("文件发送完毕！") # 打印一条消息，表示文件发送完毕
