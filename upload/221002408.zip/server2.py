
import socket # 导入socket模块，用于网络通信
import os # 导入os模块，用于处理文件和目录
import threading # 导入threading模块，用于创建和管理线程

def handle_client(client_socket, client_address): # 定义一个函数，用于处理客户端
    while True: # 循环，直到没有数据接收
        data, addr = client_socket.recvfrom(1024) # 从套接字接收数据，最多接收1024字节
        if not data: # 如果没有数据了，就跳出循环
            break
        # 从数据中获取文件名和文件数据
        fileinfo, filedata = data.split(b'\0', 1)
        command, filename = fileinfo.split(b'FILE', 1)
        filename = filename.decode()

        # 将数据写入文件
        with open(os.path.join('/home/jdqi/Desktop/here', filename), 'ab') as f:
            f.write(filedata)

    client_socket.close() # 关闭套接字

def start_server(): # 定义一个函数，用于启动服务器
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # 创建一个UDP套接字
    server_socket.bind(('0.0.0.0', 8000)) # 将套接字绑定到一个地址和端口

    while True: # 循环，直到程序被终止
        print("等待连接...") # 打印一条消息，表示正在等待连接
        client_socket, client_address = server_socket.accept() # 接受一个新的连接
        print(f"接受来自{client_address}的连接") # 打印一条消息，表示已接受连接

        # 创建一个新的线程来处理这个客户端
        client_thread = threading.Thread(target=handle_client, args=(client_socket, client_address))
        client_thread.start() # 启动线程

if __name__ == "__main__":
    start_server() # 调用start_server函数启动服务器

